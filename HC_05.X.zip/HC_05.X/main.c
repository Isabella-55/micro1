/*
 * File:   main.c
 * Author: Mercy Rocio
 *
 * Created on 28 de abril de 2025, 12:55 PM
 */


#include <xc.h>

void main(void) {
    return;
}
