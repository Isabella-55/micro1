#include <xc.h>
#include <stdio.h>
#include "LCD.h"
#include "Config.h"
#include "i2c.h"
#include "ds1307.h"

void main(void) {
    unsigned char h, m, s, d, mo, y;
    char buffer[17];

    // Configuraci�n del sistema
    OSCCONbits.IRCF = 0b111;   // Frecuencia de 8 MHz
    OSCCONbits.SCS = 0b10;     // Usar reloj interno
    ADCON1 = 0x0F;             // Deshabilitar entradas anal�gicas

    // Inicializar LCD y I2C
    LCD_Init();
    LCD_Clear();
    I2C_Master_Init(100000);   // Inicializar I2C a 100 kHz

    // Mensaje de inicio
    LCD_String_xy(0, 0, "Iniciando RTC...");
    __delay_ms(1000);
    LCD_Clear();

    // Inicializar RTC (verifica si estaba detenido)
    RTC_Init();

    // Opcional: Configurar fecha/hora inicial si el RTC est� en valores inv�lidos
    if (y == 0) {  // Si el a�o es 0, asumimos que el RTC no est� configurado
        RTC_SetDateTime(12, 0, 0, 1, 1, 25);  // 12:00:00 01/01/2025
        LCD_String_xy(0, 0, "RTC configurado");
        __delay_ms(2000);
        LCD_Clear();
    }

    // Obtener fecha/hora actual del RTC
    RTC_GetDateTime(&h, &m, &s, &d, &mo, &y);

    // Mostrar fecha y hora de arranque
    sprintf(buffer, "Inicio: %02d/%02d/20%02d", d, mo, y);
    LCD_String_xy(0, 0, buffer);
    sprintf(buffer, "%02d:%02d:%02d", h, m, s);
    LCD_String_xy(1, 0, buffer);
    __delay_ms(3000);  // Mostrar durante 3 segundos
    LCD_Clear();

    // Bucle principal: actualizar fecha/hora en tiempo real
    while (1) {
        RTC_GetDateTime(&h, &m, &s, &d, &mo, &y);
        
        // Mostrar fecha (formato: DD/MM/YYYY)
        sprintf(buffer, "Fecha:%02d/%02d/20%02d", d, mo, y);
        LCD_String_xy(0, 0, buffer);

        // Mostrar hora (formato: HH:MM:SS)
        sprintf(buffer, "Hora: %02d:%02d:%02d", h, m, s);
        LCD_String_xy(1, 0, buffer);

        __delay_ms(1000);  // Actualizar cada 1 segundo
    }
}